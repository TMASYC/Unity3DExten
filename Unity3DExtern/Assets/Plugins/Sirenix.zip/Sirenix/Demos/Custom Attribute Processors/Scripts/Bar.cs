﻿namespace Sirenix.OdinInspector.Demos
{
    using UnityEngine;

    public class Bar : Foo
    {
        public GameObject D, E, F;
    }
}